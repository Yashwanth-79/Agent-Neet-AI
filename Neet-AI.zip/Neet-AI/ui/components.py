import streamlit as st
from PIL import Image
from .styles import apply_custom_styles

def render_header():
    st.markdown(apply_custom_styles(), unsafe_allow_html=True)
    st.markdown(
        """
        <div class="main-header">
            <h1>NEET Mentor - AI Study Companion</h1>
            <p>Your personalized AI-powered NEET preparation assistant</p>
        </div>
        """,
        unsafe_allow_html=True
    )

def render_file_upload_section():
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("📚 Study Materials")
    pdf_file = st.file_uploader(
        "Upload your study materials (PDF)",
        type="pdf",
        help="Upload your PDF study materials to generate contextual questions"
    )
    st.markdown('</div>', unsafe_allow_html=True)
    return pdf_file

def render_input_section():
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("📝 Input")
    input_type = st.radio(
        "Select input type:",
        ["Text", "Image"],
        help="Choose whether to input text or upload an image"
    )
    
    input_data = None
    if input_type == "Image":
        img_file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])
        if img_file:
            input_data = Image.open(img_file)
            st.image(input_data, caption="Uploaded Image", use_column_width=True)
            st.info("The image will be analyzed to generate relevant questions.")
    else:
        input_data = st.text_area(
            "Enter your text input:",
            placeholder="Enter concept or topic description...",
            height=150
        )
    st.markdown('</div>', unsafe_allow_html=True)
    return input_type, input_data

def render_subject_selection():
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("📋 Subject Selection")
    col1, col2 = st.columns(2)
    with col1:
        subject = st.selectbox(
            "Select Subject",
            ["Physics", "Chemistry", "Biology"],
            help="Choose the subject for question generation"
        )
    with col2:
        topic = st.text_input(
            "Enter specific topic (optional)",
            placeholder="e.g., Thermodynamics",
            help="Specify a particular topic within the selected subject"
        )
    st.markdown('</div>', unsafe_allow_html=True)
    return subject, topic

def render_generate_button():
    st.markdown(
        """
        <div style="text-align: center; padding: 1rem;">
            <button class="generate-button" type="submit">
                Generate Questions
            </button>
        </div>
        """,
        unsafe_allow_html=True
    )
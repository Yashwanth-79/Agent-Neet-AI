def apply_custom_styles():
    return """
    <style>
        .stApp {
            background-color: #f0f4f8;  /* Light blue-grey background */
        }
        .main-header {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);  /* Modern gradient */
            padding: 2rem;
            border-radius: 15px;
            color: white;
            text-align: center;
            margin-bottom: 2rem;
            box-shadow: 0 4px 15px rgba(79, 172, 254, 0.2);
        }
        
        .upload-section {
            border: 2px dashed #4facfe;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            margin: 1rem 0;
            background-color: rgba(79, 172, 254, 0.05);
        }
        .subject-selector {
            background-color: #fafbfd;
            padding: 1.2rem;
            border-radius: 12px;
            border: 1px solid rgba(230, 236, 245, 0.7);
        }
        .generate-button {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 0.7rem 2.5rem;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(79, 172, 254, 0.2);
        }
        .generate-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(79, 172, 254, 0.3);
        }

        /* Additional styling for better text readability */
        h1, h2, h3 {
            color: #2d3748;
        }
        p {
            color: #4a5568;
        }
        .stTextInput input {
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        .stTextInput input:focus {
            border-color: #4facfe;
            box-shadow: 0 0 0 2px rgba(79, 172, 254, 0.2);
        }
        .stSelectbox select {
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
    </style>
    """
import os
import streamlit as st
from utils.document_processor import DocumentProcessor
from utils.input_processor import process_input
from agents.expert_agent import create_subject_expert, create_question_task
from ui.components import (
    render_header,
    render_file_upload_section,
    render_input_section,
    render_subject_selection
)

# Initialize DocumentProcessor
doc_processor = DocumentProcessor()

# Render UI Components
render_header()

# Study material upload
pdf_file = render_file_upload_section()
if pdf_file:
    with st.spinner("Processing your study materials..."):
        with open("temp.pdf", "wb") as f:
            f.write(pdf_file.getvalue())
        doc_processor.add_documents_to_vectorstore("temp.pdf")
        os.remove("temp.pdf")
        st.success("✅ Materials processed successfully!")

# Input selection
input_type, input_data = render_input_section()

# Subject and topic selection
subject, topic = render_subject_selection()

# Generate button
if st.button("Generate Questions", key="generate_button"):
    if input_data:
        with st.spinner("🔄 Generating NEET questions..."):
            context = []
            if topic:
                search_results = doc_processor.search_vectorstore(f"NEET {subject} {topic}")
                context = [doc.page_content for doc in search_results]
            
            processed_input = process_input(input_data, input_type.lower())
            expert = create_subject_expert(subject)
            result = create_question_task(expert, subject, topic, processed_input, context)
            
            st.markdown('<div class="card">', unsafe_allow_html=True)
            st.markdown("### 📝 Generated Questions")
            st.markdown(result.print_response())
            st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.warning("⚠️ Please provide either text input or upload an image.")
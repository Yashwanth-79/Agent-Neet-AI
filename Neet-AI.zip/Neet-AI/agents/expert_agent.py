from phi.agent import Agent
from config.llm_config import phi_llm

def create_subject_expert(subject):
    """Create a subject-specific NEET expert agent."""
    return Agent(
        role=f"NEET {subject} Expert",
        goal=f"Generate detailed {subject} questions following NEET examination standards",
        backstory=f"""
            You are an experienced NEET {subject} expert with deep understanding 
            of the examination pattern and curriculum. You excel at creating 
            questions that test conceptual understanding.
        """,
        allow_delegation=False,
        verbose=True,
        model=phi_llm,
        debug_mode=True
    )

def create_question_task(agent, subject, topic, processed_input, context):
    """Create a task for question generation with ReAct prompting."""
    context_text = "\n".join(context) if context else "No additional context"

    prompt = f"""Follow this ReAct (Reasoning and Acting) framework to generate a NEET question:

 Thought: Analyze the input and context
   - What is the key concept from the {subject} input?
   - What relevant information is available in the context?
   - What difficulty level is appropriate for NEET?

 Action: Plan the question structure
   - Identify the core concept to test
   - Determine question format (MCQ/numerical/theoretical)
   - Plan necessary calculations or reasoning steps

 Observation: Review available materials
   - Input material: {processed_input}
   - Context material: {context_text}
   - Topic focus: {topic}

 Question Generation: Generate 5 Question including the pdf and other commonly asked from your knowledge base
   - Create a clear, unambiguous question
   - Include any necessary diagrams or data
   - Provide 4 options if MCQ
   
 Answer Explanation:
   - Provide the correct answer
   - Give a detailed step-by-step solution
   - Explain the underlying concept
   - Add relevant NEET exam tips
"""

    return Agent(
        description=prompt,
        expected_output="""A complete NEET question with:
                           1. Question text
                           2. Multiple choice options or solution approach
                           3. Correct answer
                           4. Detailed explanation
                           5. Conceptual insights""",
        agent=agent,
        model=phi_llm
    )
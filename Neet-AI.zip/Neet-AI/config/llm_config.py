import os
from dotenv import load_dotenv
import google.generativeai as genai
from phi.model.google import Gemini

# Load environment variables
load_dotenv()

# Configure Gemini
API_KEY = "AIzaSyBGarpkJMffycGkdhU2ivf6YjgNGRYg138"
genai.configure(api_key=API_KEY)

gemini_llm = genai.GenerativeModel(
    model_name="gemini-1.5-pro"
)

# Create Phi's LLM object
phi_llm = Gemini(
    id="gemini-1.5-pro", 
    api_key=API_KEY
)